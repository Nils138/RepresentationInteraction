package nl.ru.ai.vroon.mdp;

import java.util.ArrayList;

public class ValueIteration {
	ArrayList<double[]> Vs;
	private MarkovDecisionProblem mdp;
	private Field[][] landscape;
	Action[] possibleActions = { Action.RIGHT, Action.UP, Action.LEFT, Action.DOWN };
	double threshold;
	double gamma;
	private int width;
	private int height;
	int pos;
	int xPosition;
	int yPosition;

	/**
	 * Constructor for the ValueIteration class
	 * @param mdp
	 */
	
	public ValueIteration(MarkovDecisionProblem mdp) {
		Vs = new ArrayList<double[]>();
		threshold = 0.02;
		gamma = 0.9;
		this.mdp = mdp;
		this.width = mdp.getWidth();
		this.height = mdp.getHeight();
		this.landscape = mdp.getPlane();
		this.pos = mdp.getPos();
		this.xPosition = mdp.getStateXPosition();
		this.yPosition = mdp.getStateYPosition();
	}
	
	/**
	 * performs the value iteration algorithm
	 * @return an array of values
	 */

	public double[] valueIteration() {
		if (mdp.isTerminated())
			return null;
		Vs.add(new double[width * height]);
		while (difference() > threshold) {
			double[] current = new double[width * height];
			for (int i = 0; i < current.length; i++) {
				double total = mdp.getReward(landscape[i % width][i / width]) + gamma * getValues(i);
				current[i] = total;
			}
			Vs.add(current);
		}
		return Vs.get(Vs.size() - 1);
	}
	
	/**
	 * determines the smallest difference in change between two iterations
	 * @return a double
	 */

	public double difference() {
		if (Vs.size() < 2)
			return Double.POSITIVE_INFINITY;
		double max = 0.0;
		for (int i = 0; i < width * height; i++) {
			double diff = Math.abs(Vs.get(Vs.size() - 1)[i] - Vs.get(Vs.size() - 2)[i]);
			if (diff > max)
				max = diff;
		}
		return max;
	}
	
	/**
	 * calculates the last part of the calculation
	 * @param j
	 * @return a double
	 */

	private double getValues(int j) {
		int[] possibleStates = new int[4];
		for (int i = 0; i < possibleActions.length; i++) {
			Action A = possibleActions[i];
			xPosition = j % width;
			yPosition = j / width;
			mdp.performAction(A);
			possibleStates[i] = pos;
			mdp.performAction(Action.backAction(A));
		}
		xPosition = 0;
		yPosition = 0;
		double result = 0;
		double[] probs = mdp.getProbs();
		for (int i = 0; i < possibleStates.length; i++) {
			result += probs[i] * Vs.get(Vs.size() - 1)[possibleStates[i]];
		}
		return result;
	}
	
	/**
	 * Calculated the policy given a table from the value iteration algorithm
	 * @param Vs table of values
	 * @param k amount of steps
	 * @return a list of k optimal actions
	 */
	
	public ArrayList<Action> getPolicy(double[] V, int k) {
		mdp.restart();
		ArrayList<Action> policy = new ArrayList<Action>();
		for (int i = 0; i < k; i++) {
			double max = Double.NEGATIVE_INFINITY;
			Action opt = null; // scope
			for (Action a : possibleActions) {
				int x = xPosition;
				int y = yPosition;
				mdp.performAction(a);
				if (V[pos] > max) {
					max = V[pos];
					opt = a;
				}
				xPosition = x;
				yPosition = y;
			}
			mdp.performAction(opt);
			policy.add(opt);
		}
		return policy;
	}
}
