package nl.ru.ai.vroon.mdp;

import java.util.ArrayList;

/**
 * This main is for testing purposes (and to show you how to use the MDP class).
 * 
 * @author Jered Vroon
 *
 */
public class Main {

	/**
	 * @param args,
	 *            not used
	 */
	public static void main(String[] args) {
		valueIteration();
		qLearning();
	}

	public static void qLearning() {
		MarkovDecisionProblem mdp = new MarkovDecisionProblem();
		QLearning q = new QLearning(mdp);
		q.qLearning();
		double[][] table = q.getTable();
		for (int i = 0; i < 15; i++) {
			mdp.restart();
			while (!mdp.isTerminated()) {
				int index = mdp.max(table[mdp.getPos()]);
				mdp.performAction(mdp.possibleActions[index]);
			}
		}
	}

	public static void valueIteration() {
		MarkovDecisionProblem mdp = new MarkovDecisionProblem();
		ValueIteration vi = new ValueIteration(mdp);
		double[] values = vi.valueIteration();
		ArrayList<Action> policy = vi.getPolicy(values, 5);
		mdp.setInitialState(0, 0);
		mdp.restart();
		for (int i = 0; i < 15; i++) {
			for (int j = 0; j < 5; j++) {
				mdp.performAction(policy.get(j));
			}
			mdp.restart();
		}
	}
}
