package nl.ru.ai.vroon.mdp;

import java.util.Random;

public class QLearning {
	MarkovDecisionProblem mdp;
	Action[] possibleActions;
	double[][] table;
	Random rand;
	double epsilon;
	double gamma;
	double alpha;
	int pos;
	int index;
	
	/**
	 * constructor for the class
	 * @param mdp
	 */
	
	public QLearning(MarkovDecisionProblem mdp) {
		this.mdp = mdp;
		possibleActions = Action.possibleActions();
		table = new double[mdp.getWidth() * mdp.getHeight()][possibleActions.length];
		fillTable();
		rand = new Random();
		epsilon = 1;
		gamma = 0.9;
		alpha = 1;
		pos = mdp.getPos();
	}
	
	/**
	 * fills the table with the reward of non-reward fields
	 */

	public void fillTable() {
		for (int i = 0; i < table.length; i++) {
			for (int j = 0; j < table[i].length; j++) {
				table[i][j] = mdp.getNoReward();
			}
		}
	}
	
	/**
	 * performs the Q-learning algorithm
	 */

	public void qLearning() {
		for (int i = 0; i < 50; i++) {
			if (rand.nextDouble() < epsilon)
				explore();
			else
				exploit();
			updateTable();
			epsilon -= 0.04;
		}

	}
	
	/**
	 * explore the field randomly
	 */

	public void explore() {
		index = (int) (4 * rand.nextDouble());
		int temp = pos;
		mdp.performAction(possibleActions[index]);
		pos = mdp.getPos();
		if (temp == pos)
			explore();
	}

	/**
	 * exploit by going to the field with the highest value
	 */
	
	public void exploit() {
		double max = Double.NEGATIVE_INFINITY;
		for (int i = 0; i < possibleActions.length; i++) {
			if (table[pos][i] > max) {
				max = table[pos][i];
				index = i;
			}
		}
		int temp = pos;
		mdp.performAction(possibleActions[index]);
		pos = mdp.getPos();
		if (temp == pos)
			exploit();
	}

	/**
	 * updates the table with a new value
	 */
	
	public void updateTable() {
		pos = mdp.getPos();
		table[pos][index] += alpha * (mdp.getReward() + gamma * futureReward() - table[pos][index]);
	}

	/**
	 * determines the future reward; separate function for visibility
	 * @return a double
	 */
	
	public double futureReward() {
		double[] rewards = new double[4];
		for (int i = 0; i < possibleActions.length; i++) {
			Action a = possibleActions[i];
			int x = mdp.getStateXPosition();
			int y = mdp.getStateYPosition();
			mdp.performAction(a);
			rewards[i] = mdp.getReward();
			mdp.setState(x, y);
		}
		return mdp.max(rewards);
	}
	
	/**
	 * returns the table
	 * @return two-dimensional array
	 */

	public double[][] getTable() {
		return table;
	}
}
