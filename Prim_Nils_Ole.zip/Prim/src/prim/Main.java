package prim;

/**
 * 
 * @author Ole ten Hove s1007616
 * @author Nils Kimman s1007368
 *
 */

public class Main {
	
	public static void main(String[] args) {
		Edge[] edges = new Edge[3];
		edges[0] = new Edge(3, 0);
		edges[1] = new Edge(5, 1);
		edges[2] = new Edge(2, 2);
		
		Vertex[] vertices = new Vertex[3];
		vertices[0] = new Vertex(edges[0], edges[1]);
		vertices[1] = new Vertex(edges[0], edges[2]);
		vertices[2] = new Vertex(edges[1], edges[2]);
		
		edges[0].setVertices(vertices[0], vertices[1]);
		edges[1].setVertices(vertices[0], vertices[2]);
		edges[2].setVertices(vertices[1], vertices[2]);
		
		Graph g = new Graph(vertices);
		g.prim();
	}
}
