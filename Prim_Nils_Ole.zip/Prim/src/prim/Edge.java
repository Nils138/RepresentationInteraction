package prim;

/**
 * 
 * @author Ole ten Hove s1007616
 * @author Nils Kimman s1007368
 *
 */

public class Edge {
	private final int nr, weight;
	private Vertex v1, v2;

	public Edge(int weight, int nr) {
		this.weight = weight;
		this.nr = nr;
		this.v1 = null;
		this.v2 = null;
	}

	public int getNr() {
		return nr;
	}
	
	public int getWeight() {
		return weight;
	}

	public void setVertices(Vertex v1, Vertex v2) {
		this.v1 = v1;
		this.v2 = v2;
	}
	
	public Vertex[] getVertices() {
		Vertex[] vertices = {v1, v2};
		return vertices;
	}
	
	@Override
	public String toString() {
		return String.valueOf(nr);
	}
}
