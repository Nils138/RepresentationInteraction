package prim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * 
 * @author Ole ten Hove s1007616
 * @author Nils Kimman s1007368
 *
 */

public class Graph {
	private final Vertex root;
	private ArrayList<Vertex> vertices;

	public Graph(Vertex[] vertices) {
		this.root = vertices[0];
		this.vertices = new ArrayList<>(Arrays.asList(vertices));
	}

	public void prim() {
		// init
		Comparator<Edge> eComparator = (e1, e2) -> e1.getWeight() - e2.getWeight();
		PriorityQueue<Edge> PQ = new PriorityQueue<>(eComparator);
		PQ.addAll(root.getEdges());
		ArrayList<Integer> done = new ArrayList<Integer>();
		int counter1 = 0;
		int counter2 = 0;
		int counter3 = 0;
		
		while (!vertices.isEmpty()) {
			counter1++;
			Edge e = PQ.remove();
			// Replace this with an assignment to save the path to a variable instead of
			// printing it immediately
			System.out.println("Edge: " + e + ", weight: " + e.getWeight());
			done.add(e.getNr());
			vertices.removeAll(new ArrayList<Vertex>(Arrays.asList(e.getVertices())));
			for (Vertex vertex : e.getVertices()) {
				counter2++;
				if (!vertices.contains(vertex)) {
					for (Edge edge : vertex.getEdges()) {
						counter3++;
						if (!done.contains(edge.getNr()) && !PQ.contains(edge)) {
							PQ.add(edge);
						}
					}
				}
			}
		}
		System.out.println("Counter 1: " + counter1);
		System.out.println("Counter 2: " + counter2);
		System.out.println("Counter 3: " + counter3);
	}
}
