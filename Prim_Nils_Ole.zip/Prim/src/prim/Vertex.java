package prim;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * 
 * @author Ole ten Hove s1007616
 * @author Nils Kimman s1007368
 *
 */

public class Vertex {
	private ArrayList<Edge> edges;

	public Vertex(Edge... edges) {
		this.edges = new ArrayList<Edge>(Arrays.asList(edges));
	}

	public ArrayList<Edge> getEdges() {
		return edges;
	}
}
