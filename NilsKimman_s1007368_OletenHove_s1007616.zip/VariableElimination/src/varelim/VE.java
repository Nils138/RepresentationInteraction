package varelim;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

public class VE {

	// Attributes
	// All factors:
	private static ArrayList<Factor> factors;
	// List of observed variables:
	private static ArrayList<Variable> observed;
	// Variables to be eliminated:
	private static ArrayList<Variable> elimVars;
	// Current variable to be eliminated
	private static Variable currentVar;
	// Writer
	private static PrintWriter writer;

	/**
	 * Constructor for the VE class
	 * 
	 * @param vs - list of variables
	 * @param ps - list of probability tables
	 * @param query - query variable
	 * @param observed - list of observed variables
	 * @param ui - user interface
	 */

	public VE(ArrayList<Variable> vs, ArrayList<Table> ps, Variable query, ArrayList<Variable> observed) {
		factors = new ArrayList<Factor>();
		for (Table tab : ps) {
			factors.add(new Factor(tab));
		}

		VE.observed = observed;

		VE.elimVars = getElimVars(vs, query);
		
		try {
			writer = new PrintWriter("log.txt");
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
			e.printStackTrace();
		}
		
		writer.println("Variables to be eliminated: ");
		for (Variable var : elimVars) {
			writer.println(var);
		}
		writer.println("In that order\n");

		removeObserved();
	}

	/**
	 * Evaluates the observed values in all tables; removes factors without any
	 * variables left
	 */

	private void removeObserved() {
		// Iterator to prevent concurrent modification errors
		Iterator<Factor> iter = factors.iterator();
		while (iter.hasNext()) {
			Factor fac = iter.next();

			for (Variable var : observed) {
				if (fac.getVariables().contains(var)) {
					// To get the getIndex() function to work properly:
					currentVar = var;
					fac.observe(getIndex(fac), var.getObservedValue());
				}
			}

			if (fac.getVariables().size() == 0)
				iter.remove();
		}
	}

	/**
	 * Applies the variable elimination algorithm
	 */

	public static void eliminate() {
		for (Variable var : elimVars) {
			
			writer.println("\nFactors: " + factors);
			
			// Update current variable to eliminate:
			currentVar = var;
			writer.println("Current variable to eliminate: " + currentVar.getName());

			// Get all factors which include this variable:
			ArrayList<Factor> currentFactors = getFactors();
			writer.println("Relevant factors: " + currentFactors + "\n");

			// Multiply + marginalize + add to list
			factors.add(marginalize(multiply(currentFactors)));
			currentFactors.clear();

			// Print the new factor
			writer.println("Added factor: " + factors.get(factors.size() - 1) + "\n");
		}

		// Normalize values
		normalize(factors.get(factors.size() - 1));

		// Print result
		writer.println("\nFinal result:" + factors.get(0));
		writer.close();
	}

	/**
	 * Determines the variables which are to be eliminated
	 * 
	 * @param vs
	 * @param query
	 * @return list of all variables excluding the observed/query variables
	 */

	private static ArrayList<Variable> getElimVars(ArrayList<Variable> vs, Variable query) {
		ArrayList<Variable> vars = new ArrayList<Variable>();
		for (Variable var : vs) {
			if (!observed.contains(var) && var != query)
				vars.add(var);
		}
		return vars;
	}

	/**
	 * Find all factors which include given variable
	 * 
	 * @param factors
	 * @return a list of probability tables in which the given variable occurs
	 */

	private static ArrayList<Factor> getFactors() {
		ArrayList<Factor> currentFactors = new ArrayList<>();
		Iterator<Factor> iter = factors.iterator();

		while (iter.hasNext()) {

			Factor fac = iter.next();
			if (fac.getVariables().contains(currentVar)) {
				currentFactors.add(fac);
				iter.remove();
			}
		}

		return currentFactors;
	}

	/**
	 * Multiplies any number of factors with each other
	 * 
	 * @param factors
	 * @return multiplication of multiple factors
	 */

	private static Factor multiply(ArrayList<Factor> factors) {
		switch (factors.size()) {
		case 0:
			throw new NullPointerException("Length is 0");
		case 1:
			return factors.get(0);
		case 2:
			return mult(factors.get(0), factors.get(1));
		default:
			Factor fac = factors.get(0);
			factors.remove(fac);
			return mult(multiply(factors), fac);
		}
	}

	/**
	 * Multiplies two factors
	 * 
	 * @param f1
	 * @param f2
	 * @return multiplication of two factors; empty ProbRow if no pivot found
	 */

	private static Factor mult(Factor f1, Factor f2) {
		writer.println("Multiplying: " + f1 + "and " + f2);
		// Calculate probability rows:
		ArrayList<ProbRow> probs = new ArrayList<>();
		// Get indices of the current variable in both factors
		int i1 = getIndex(f1);
		int i2 = getIndex(f2);

		for (ProbRow p2 : f2.getValues()) {

			// Value of the current variable in p2
			String v2 = p2.getValues().get(i2);
			for (ProbRow p1 : f1.getValues()) {

				// Value of the current variable in p1
				String v1 = p1.getValues().get(i1);
				if (v2.equals(v1)) {
					// Calculate new probability
					double prob = p1.getProb() * p2.getProb();

					// Determine new values
					ArrayList<String> values = new ArrayList<>();
					values.addAll(p1.getValues());
					values.addAll(p2.getValues());
					// Current variable has been added twice:
					values.remove(i1);

					probs.add(new ProbRow(values, prob));
				}
			}
		}

		// Determine variables
		ArrayList<Variable> vars = f1.getVariables();
		vars.addAll(f2.getVariables());
		// Current variable has been added twice:
		vars.remove(i1);
		return new Factor(probs, vars);
	}

	/**
	 * Marginalize a factor by eliminating the current variable
	 * 
	 * @param fac
	 * @return a new probability table excluding the given variable
	 */

	private static Factor marginalize(Factor fac) {
		
		writer.println("Marginalizing: " + fac);
		
		ArrayList<ProbRow> probs = new ArrayList<>();
		// Get index of the current variable in the factor
		int index = getIndex(fac);
		// Keep track of rows which have already been evaluated and added
		ArrayList<Integer> done = new ArrayList<>();

		for (int i = 0; i < fac.getValues().size(); i++) {

			// Skip rows which have already been done
			if (!done.contains(i)) {

				// Get values of the current probability row
				ArrayList<String> current = fac.getValues().get(i).getValues();
				double prob = 0;

				for (int j = 0; j < fac.getValues().size(); j++) {

					ProbRow p = fac.getValues().get(j);
					// Compare current probability row with ever other row
					if (match(p.getValues(), current, index)) {

						prob += p.getProb();
						// Remember this row to avoid counting rows twice
						done.add(j);
					}
				}
				// Determine values
				ArrayList<String> values = fac.getValues().get(i).getValues();
				values.remove(index);

				probs.add(new ProbRow(values, prob));
			}
		}

		// Determine variables
		ArrayList<Variable> vars = new ArrayList<>();
		vars.addAll(fac.getVariables());
		// Current variable is added twice:
		vars.remove(currentVar);
		return new Factor(probs, vars);
	}

	/**
	 * Compares two lists of values to determine whether to merge rows or not. The
	 * rows match if all the other variables have the same values
	 * 
	 * @param m1
	 * @param m2
	 * @param index
	 * @return true if the rows match, false otherwise
	 */

	private static boolean match(ArrayList<String> m1, ArrayList<String> m2, int index) {
		// Compare sizes
		if (m1.size() != m2.size())
			return false;

		// Check values
		for (int i = 0; i < m1.size(); i++) {
			if (!m1.get(i).equals(m2.get(i)) && i != index)
				return false;
		}
		return true;
	}

	/**
	 * Retrieves the index of the current variable in the given factor
	 * 
	 * @param fac
	 * @return index of current variable, -1 if not found
	 */

	private static int getIndex(Factor fac) {
		for (int i = 0; i < fac.getVariables().size(); i++) {
			if (fac.getVariables().get(i).getName().equals(currentVar.getName()))
				return i;
		}
		return -1;
	}

	/**
	 * Normalize a table so the sum equals 1
	 * 
	 * @param fac
	 */

	private static void normalize(Factor tab) {
		// Get total sum
		double total = 0;
		for (ProbRow prob : tab.getValues()) {
			total += prob.getProb();
		}

		// Divide each value by total sum
		for (ProbRow prob : tab.getValues()) {
			prob.setProb(prob.getProb() / total);
		}
	}
}
