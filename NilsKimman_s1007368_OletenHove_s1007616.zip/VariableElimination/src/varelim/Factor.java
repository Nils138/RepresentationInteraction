package varelim;

import java.util.ArrayList;
import java.util.Iterator;

public class Factor {
	// Attributes:
	private ArrayList<ProbRow> values;
	private ArrayList<Variable> variables;

	/**
	 * Constructor, converts a table into a factor
	 * 
	 * @param a probability table
	 */

	public Factor(Table p) {
		this.values = p.getTable();
		this.variables = p.getVariables();
	}

	/**
	 * Second constructor, specifying the probability table and variables separately
	 * 
	 * @param values
	 * @param variables
	 */

	public Factor(ArrayList<ProbRow> values, ArrayList<Variable> variables) {
		this.values = values;
		this.variables = variables;
	}

	/**
	 * Fills in an observed value and updates the probability table
	 * 
	 * @param index of the observed variable
	 * @param observed value
	 */

	public void observe(int i, String value) {
		variables.remove(i);
		Iterator<ProbRow> iter = values.iterator();
		while (iter.hasNext()) {
			ProbRow p = iter.next();
			if (!p.getValues().get(i).equals(value))
				iter.remove();
			else
				p.getValues().remove(i);
		}
	}

	/**
	 * Getter for the variables
	 * 
	 * @return variables as list
	 */

	public ArrayList<Variable> getVariables() {
		return variables;
	}

	/**
	 * Getter for the probability table
	 * 
	 * @return probabilities in a list
	 */

	public ArrayList<ProbRow> getValues() {
		return values;
	}

	/**
	 * toString method for nicer prints
	 */

	public String toString() {
		String factorString = "";
		for (Variable var : variables) {
			factorString += var.getName() + " ";
		}
		factorString += ": ";
		for (ProbRow value : values) {
			factorString += value.getProb() + " ";
		}
		return factorString;
	}
}
